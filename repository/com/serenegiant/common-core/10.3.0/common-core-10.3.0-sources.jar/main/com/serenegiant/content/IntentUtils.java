package com.serenegiant.content;
/*
 * libcommon
 * utility/helper classes for myself
 *
 * Copyright (c) 2014-2026 saki t_saki@serenegiant.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

import android.content.Intent;
import android.os.Bundle;

import com.serenegiant.utils.BundleUtils;

import androidx.annotation.Nullable;

public class IntentUtils {
	private static final boolean DEBUG = false;  // set false on production
	private static final String TAG = IntentUtils.class.getSimpleName();

	private IntentUtils() {
		// インスタンス化をエラーとするためにデフォルトコンストラクタをprivateに
	}

	public static String toString(@Nullable final Intent intent) {
		if (intent == null) {
			return "Intent{null}";
		} else {
			final StringBuilder sb = new StringBuilder("Intent{");
			sb.append("action="); sb.append(intent.getAction());
			sb.append(",flags="); sb.append(String.format("0x%08x", intent.getFlags()));
			final Bundle extra = intent.getExtras();
			sb.append(",extra={"); sb.append(BundleUtils.toString(extra)); sb.append("}");
			sb.append("}");
			return sb.toString();
		}
	}
}
