package com.serenegiant.media;
/*
 * libcommon
 * utility/helper classes for myself
 *
 * Copyright (c) 2014-2026 saki t_saki@serenegiant.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
*/

import androidx.annotation.WorkerThread;

/**
 * 映像が更新されたときの通知用コールバックリスナー
 */
public interface OnFrameAvailableListener {
	/**
	 * 映像が更新されたときの通知用コールバック
	 * XXX 現在は描画スレッド上で呼び出しているので時間のかかる処理をしないこと!!
	 */
	@WorkerThread
	public void onFrameAvailable();
}
